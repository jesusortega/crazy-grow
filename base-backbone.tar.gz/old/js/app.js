var app = (function() {
    var DesarrolladorModel = Backbone.Model.extend({
        defaults:{
            nombre: "Pepito Perez",
            edad: 24,
            lenguajes:[]
        }
    }); 
})();